#include "s21_string.h"

/* Функция s21_strstr осуществляет поиск подстроки str2 в строке str1.
Она ищет первое вхождение подстроки str2 в строке str1
и возвращает указатель на начало найденной подстроки в строке str1.
Если подстрока не найдена, функция возвращает S21_NULL. */

int sravnen(const char *str1, const char *str2) {
  int result = 0;
  int break_flag = 0;
  while (*str1 && *str2 && !break_flag) {
    if (*str1 != *str2) {
      result = 0;
      break_flag = 1;
    }

    str1++;
    str2++;
  }
  result = (*str2 == '\0');
  return result;
}

char *s21_strstr(const char *str1, const char *str2) {
  const char *result = S21_NULL;
  int flag = 1;
  int break_flag = 0;

  if (s21_strlen(str1) == 0 && s21_strlen(str2) == 0) {
    flag = 0;
    result = "";
  }
  while (*str1 && !break_flag) {
    if ((*str1 == *str2 && sravnen(str1, str2)) ||
        (*str1 == '\0' || *str2 == '\0')) {
      result = str1;
      flag = 0;
      break_flag = 1;
    }
    str1++;
  }

  return flag ? S21_NULL : (char *)result;
}
